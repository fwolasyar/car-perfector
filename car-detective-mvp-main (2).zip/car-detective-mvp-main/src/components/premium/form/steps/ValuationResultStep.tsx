
import React, { useEffect } from 'react';
import { useValuationResult } from '@/hooks/useValuationResult';
import { FormData } from '@/types/premium-valuation';
import { ValuationResults } from '@/components/premium/common/ValuationResults';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle, Download, Mail } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { toast } from 'sonner';

interface ValuationResultStepProps {
  step: number;
  formData: FormData;
  setFormData: React.Dispatch<React.SetStateAction<FormData>>;
  updateValidity: (step: number, isValid: boolean) => void;
}

export function ValuationResultStep({
  step,
  formData,
  updateValidity
}: ValuationResultStepProps) {
  const valuationId = formData.valuationId;
  
  const {
    data: result,
    isLoading,
    isError,
    refetch,
  } = useValuationResult(valuationId);

  // Set step validity
  useEffect(() => {
    updateValidity(step, !!result);
  }, [result, step, updateValidity]);

  // Refetch when valuationId changes
  useEffect(() => {
    if (valuationId) {
      refetch();
    }
  }, [valuationId, refetch]);

  const handleDownloadPdf = async () => {
    try {
      // Here we'd generate PDF using a utility function
      // For now, just show a toast
      toast.success("PDF download started!");
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast.error("Failed to generate PDF report");
    }
  };

  const handleEmailPdf = async () => {
    try {
      // Here we'd call the edge function to email the PDF
      // For now, just show a toast
      toast.success("PDF emailed successfully!");
    } catch (error) {
      console.error("Error emailing PDF:", error);
      toast.error("Failed to email PDF report");
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
        <p className="text-gray-600">Loading valuation results...</p>
      </div>
    );
  }

  if (isError || !result) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription className="space-y-2">
          <p>Could not load valuation results. Please try again.</p>
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Valuation Results</h2>
        <p className="text-gray-600 mb-6">
          Based on your vehicle details, our AI pricing model has generated the following valuation.
        </p>
      </div>

      <ValuationResults
        estimatedValue={result.estimated_value}
        confidenceScore={result.confidence_score}
        priceRange={result.price_range}
        adjustments={result.adjustments}
      />

      <div className="flex flex-col sm:flex-row gap-4 mt-8">
        <Button onClick={handleDownloadPdf} className="flex-1 h-11 text-sm font-medium transition-all">
          <Download className="h-4 w-4 mr-2" />
          Download PDF Report
        </Button>
        <Button variant="outline" onClick={handleEmailPdf} className="flex-1 h-11 text-sm font-medium transition-all">
          <Mail className="h-4 w-4 mr-2" />
          Email Me the Report
        </Button>
      </div>
    </div>
  );
}

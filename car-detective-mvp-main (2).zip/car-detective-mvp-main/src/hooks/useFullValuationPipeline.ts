
import { useValuationPipeline } from './valuation-pipeline';

export function useFullValuationPipeline() {
  return useValuationPipeline();
}


export interface StepConfig {
  component: string;
  shouldShow: boolean;
  props: Record<string, unknown>;
}
